import './App.css';
import { BrowserRouter, NavLink, Route, Routes, useLocation } from 'react-router-dom';
import CreateTask from './pages/CreateTask';
import TaskList from './pages/TaskList';
import EditTask from './pages/EditTask';

function Navigation() {
  const location = useLocation();
  
  return (
    <nav className="navbar">
      <div className="navbar-content">
        <div className="navbar-brand">TaskHub</div>
        <div className="navbar-links">
          <NavLink 
            to="/" 
            className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
          >
            Tasks
          </NavLink>
          <NavLink 
            to="/create" 
            className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
          >
            Create Task
          </NavLink>
        </div>
      </div>
    </nav>
  );
}

function App() {
  return (
    <BrowserRouter>
      <div className="app-container">
        <Navigation />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<TaskList />} />
            <Route path="/create" element={<CreateTask />} />
            <Route path="/edit/:id" element={<EditTask />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}

export default App;
