import { useState, useEffect } from 'react';
import { api } from '../api/axios';
import { useNavigate, useParams } from 'react-router-dom';
import './EditTask.css';

export default function EditTask() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState('todo');
  const [priority, setPriority] = useState('medium');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const fetchTask = async () => {
      try {
        setLoading(true);
        const res = await api.get(`/tasks/${id}`);
        setTitle(res.data.title);
        setDescription(res.data.description || '');
        setStatus(res.data.status);
        setPriority(res.data.priority);
      } catch (err) {
        console.error(err);
        alert('Failed to fetch task');
        navigate('/');
      } finally {
        setLoading(false);
      }
    };

    fetchTask();
  }, [id, navigate]);

  const handleUpdate = async (e) => {
    e.preventDefault();
    if (!title.trim()) {
      alert('Please enter a task title');
      return;
    }

    try {
      setSaving(true);
      await api.patch(`/tasks/${id}`, {
        title,
        description,
        status,
        priority,
      });
      navigate('/');
    } catch (err) {
      console.error(err);
      alert('Failed to update task. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Loading task...</p>
      </div>
    );
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'done':
        return '#10b981';
      case 'in-progress':
        return '#f59e0b';
      case 'todo':
        return '#6366f1';
      default:
        return '#64748b';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high':
        return '#ef4444';
      case 'medium':
        return '#f59e0b';
      case 'low':
        return '#10b981';
      default:
        return '#64748b';
    }
  };

  return (
    <div className="form-container">
      <div className="form-header">
        <h1 className="form-title">Edit Task</h1>
        <p className="form-subtitle">Update your task details</p>
      </div>

      <form className="task-form" onSubmit={handleUpdate}>
        <div className="form-group">
          <label htmlFor="title" className="form-label">
            Task Title <span className="required">*</span>
          </label>
          <input
            id="title"
            type="text"
            className="form-input"
            placeholder="Enter task title..."
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="description" className="form-label">
            Description
          </label>
          <textarea
            id="description"
            className="form-textarea"
            placeholder="Enter task description (optional)..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows="5"
          />
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="status" className="form-label">
              Status
            </label>
            <select
              id="status"
              className="form-select"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              style={{
                borderColor: getStatusColor(status) + '40',
              }}
            >
              <option value="todo">Todo</option>
              <option value="in-progress">In Progress</option>
              <option value="done">Done</option>
            </select>
            <div 
              className="status-indicator" 
              style={{ backgroundColor: getStatusColor(status) }}
            ></div>
          </div>

          <div className="form-group">
            <label htmlFor="priority" className="form-label">
              Priority
            </label>
            <select
              id="priority"
              className="form-select"
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
              style={{
                borderColor: getPriorityColor(priority) + '40',
              }}
            >
              <option value="low">Low Priority</option>
              <option value="medium">Medium Priority</option>
              <option value="high">High Priority</option>
            </select>
            <div 
              className="priority-indicator" 
              style={{ backgroundColor: getPriorityColor(priority) }}
            ></div>
          </div>
        </div>

        <div className="form-actions">
          <button
            type="button"
            className="btn-secondary"
            onClick={() => navigate('/')}
            disabled={saving}
          >
            Cancel
          </button>
          <button
            type="submit"
            className="btn-submit"
            disabled={saving}
          >
            {saving ? (
              <>
                <div className="spinner-small"></div>
                Updating...
              </>
            ) : (
              <>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M20 6L9 17l-5-5"></path>
                </svg>
                Update Task
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
